smartladder
===========

我是一个聪明的梯子,用来干什么你懂的。_(:з」∠)_

打开即用 无需安装 简单设置，支持Windows、Linux、Mac OS X 三系统

支持Chrome Firefox Opera 等浏览器

新增Appid自动切换功能～，支持链接加密


开源协议：GPL V2
