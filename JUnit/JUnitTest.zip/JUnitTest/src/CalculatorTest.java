import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

public class CalculatorTest {

	private static Calculator calculator = new Calculator();

	@Before
	public void setUp() throws Exception {
		calculator.clear();
		System.out.println("se");
	}

	@Before
	public void haha() throws Exception {
		System.out.println("ha");
	}
	
	@Before
	public void aaha() throws Exception {
		System.out.println("aa");
	}
	
	@Before
	public void abha() throws Exception {
		System.out.println("ab");
	}
	
	@Test
	public void testAdd() {
		calculator.add(2);
		calculator.add(3);
		assertEquals(5, calculator.getResult());
	}

	@Test
	public void testSubstract() {
		calculator.add(2);
		calculator.substract(2);
		assertEquals(0, calculator.getResult());
	}

	// @Ignore("Multiply no implements")
	@Test
	public void testMultiply() {
		fail("Not yet implemented");
	}

	@Test
	public void testDivide() {
		calculator.add(8);
		calculator.divide(2);
		assertEquals(4, calculator.getResult());
	}

	@Test(timeout = 1000)
	public void squareRoot() {
		calculator.squareRoot(4);
		assertEquals(2, calculator.getResult());
	}

	@Test(expected = ArithmeticException.class)
	public void divideByZero() {
		calculator.divide(0);
	}
	
	@Test
	public void testTest(){
		calculator.test(10, 10);
	}
}
