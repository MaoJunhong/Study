/*
 * @(#)SectorCell.java
 * @author LiangZhang
 * Copyright Apr 7, 2013, LiangZhang all rights reserved
 */
package com.swrd.opengl.sector;

import com.swrd.opengl.utils.GLColor;

public class SectorCell {
	private float num;
	private GLColor color;

	public SectorCell(float num, GLColor color) {
		this.num = num;
		this.color = color;
	}

	public float getNum() {
		return num;
	}

	public GLColor getColor() {
		return color;
	}

	public static SectorCell getRandom() {
		return new SectorCell((float) Math.random(), GLColor.getRandom());
	}

}
