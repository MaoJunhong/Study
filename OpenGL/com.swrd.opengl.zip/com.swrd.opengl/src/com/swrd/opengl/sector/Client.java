/*
 * @(#)Client.java
 * @author LiangZhang
 * Copyright Apr 7, 2013, LiangZhang all rights reserved
 */
package com.swrd.opengl.sector;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import com.swrd.opengl.utils.GLColor;
import com.swrd.opengl.utils.Paint2D;
import com.swrd.opengl.utils.SWTUtils;

public class Client {

	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setLayout(new FillLayout());
		shell.setSize(800, 600);
		SWTUtils.setCenter(shell);
		// ////////////////////////

		Sector sector = new Sector(3, 3, 3.0f, 30, 1);
		for (int i = 0; i <= 10; ++i) {
			sector.addElement(SectorCell.getRandom());

		}

		final Paint2D paint = new Paint2D(shell, SWT.NONE, -10.0f, 10.0f,
				-10.0f, 10.0f, 1.0f, 3.0f, GLColor.getRandom(),
				GLColor.getRandom(), GLColor.getRandom());
		paint.addDrawable(sector);
		paint.setLayout(new FillLayout());

		// ////////////////////////

		shell.setText("SWT/Curive");
		shell.layout();
		shell.open();

		display.asyncExec(new Runnable() {
			@Override
			public void run() {
				paint.draw();
				display.asyncExec(this);
			}
		});

		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		display.dispose();
	}
}
