/*
 * @(#)Sector.java
 * @author LiangZhang
 * Copyright Apr 7, 2013, LiangZhang all rights reserved
 */
package com.swrd.opengl.sector;

import java.util.ArrayList;
import java.util.List;

import javax.media.opengl.GL;
import javax.media.opengl.glu.GLU;
import javax.media.opengl.glu.GLUquadric;

import com.swrd.opengl.utils.Drawable;
import com.swrd.opengl.utils.GLColor;

public class Sector implements Drawable {

	private List<SectorCell> list;
	private float x, y;
	private float radius;
	private int nSlices, nStacks;

	public Sector(float x, float y, float radius, int nSlices, int nStacks) {
		this.x = x;
		this.y = y;
		this.radius = radius;
		this.nSlices = nSlices;
		this.nStacks = nStacks;
		this.list = new ArrayList<SectorCell>();
	}

	@Override
	public void draw(GL gl) {
		float sum = 0;
		float angle = 0;
		float start = 0;

		for (int i = 0; i < list.size(); ++i) {
			sum += list.get(i).getNum();
		}

		gl.glMatrixMode(GL.GL_MODELVIEW);
		gl.glLoadIdentity();
		gl.glTranslatef(x, y, 0);

		GLU glu = new GLU();

		for (int i = 0; i < list.size(); ++i) {
			GLUquadric qobj = glu.gluNewQuadric();
			GLColor color;
			color = list.get(i).getColor();
			gl.glColor4f(color.color_r, color.color_g, color.color_b,
					color.color_c);
			angle = (float) (list.get(i).getNum() / sum * 360);
			glu.gluPartialDisk(qobj, 0, radius, nSlices, nStacks, start, angle);
			start += angle;
			glu.gluDeleteQuadric(qobj);
		}
		gl.glTranslatef(-x, -y, 0);
	}

	public void addElement(SectorCell cell) {
		this.list.add(cell);
	}

}
