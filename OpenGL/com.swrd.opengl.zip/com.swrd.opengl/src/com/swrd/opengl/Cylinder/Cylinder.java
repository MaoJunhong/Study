/*
 * @(#)Cylinder.java
 * @author LiangZhang
 * Copyright Apr 7, 2013, LiangZhang all rights reserved
 */
package com.swrd.opengl.Cylinder;

import java.util.ArrayList;
import java.util.List;

import javax.media.opengl.GL;

import com.swrd.opengl.utils.Drawable;

public class Cylinder implements Drawable {

	private List<CylinderCell> list;

	public Cylinder() {
		this.list = new ArrayList<CylinderCell>();
	}

	@Override
	public void draw(GL gl) {
		for (CylinderCell cell : list) {
			cell.draw(gl);
		}
	}

	public void addElement(CylinderCell ele) {
		list.add(ele);
	}
}
