/*
 * @(#)CylinderDemo.java
 * @author LiangZhang
 * Copyright Apr 3, 2013, LiangZhang all rights reserved
 */
package com.swrd.opengl.Cylinder;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import com.swrd.opengl.utils.GLColor;
import com.swrd.opengl.utils.Paint3D;
import com.swrd.opengl.utils.SWTUtils;

public class Client {

	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setLayout(new FillLayout());
		shell.setSize(800, 800);
		SWTUtils.setCenter(shell);

		// ////////////////////////

		Cylinder cylinder = new Cylinder();

		float size = 0.2f;
		for (int i = 1; i < 9; i += 2) {
			for (int j = 1; j < 9; j += 2) {
				CylinderCell ele = new CylinderCell(0.2f,
						(float) (Math.random() * 1.8f), size * i, 0.0f, size
								* j, 30, 1, GLColor.getRandom());
				cylinder.addElement(ele);
			}
		}

		final Paint3D paint = new Paint3D(shell, SWT.NONE);
		paint.addDrawable(cylinder);
		paint.setLayout(new FillLayout());

		// ////////////////////////

		shell.setText("SWT/Cylinder");
		shell.layout();
		shell.open();

		// ////////////////////////

		display.asyncExec(new Runnable() {
			@Override
			public void run() {
				paint.draw();
				display.timerExec(300, this);
			}
		});

		// ////////////////////////

		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		display.dispose();
	}

}
