/*
 * @(#)CylinderElement.java
 * @author LiangZhang
 * Copyright Apr 3, 2013, LiangZhang all rights reserved
 */
package com.swrd.opengl.Cylinder;

import javax.media.opengl.GL;
import javax.media.opengl.glu.GLU;
import javax.media.opengl.glu.GLUquadric;

import com.swrd.opengl.utils.Drawable;
import com.swrd.opengl.utils.GLColor;

public class CylinderCell implements Drawable {

	private float radius, length;
	private float rx, ry, rz;
	private int nSlices, nStacks;
	private GLColor color;

	public CylinderCell(float radius, float length, float rx, float ry,
			float rz, int nSlices, int nStacks, GLColor color) {
		this.color = color;
		this.radius = radius;
		this.length = length;
		this.rx = rx;
		this.ry = ry;
		this.rz = rz;
		this.nSlices = nSlices;
		this.nStacks = nStacks;
	}

	@Override
	public void draw(GL gl) {
		GLU glu = new GLU();
		GLUquadric qobj = glu.gluNewQuadric();
		// glu.gluQuadricDrawStyle(qobj, GLU.GLU_FILL);

		gl.glColor4f(color.color_r, color.color_g, color.color_b, color.color_c);
		gl.glTranslatef(rx, ry, rz);

		gl.glRotatef(-90.f, 1.0f, 0.0f, 0.0f);
		glu.gluDisk(qobj, 0.0f, radius, nSlices, nStacks);
		glu.gluCylinder(qobj, radius, radius, length, nSlices, nStacks);
		gl.glTranslatef(0.0f, 0.0f, length);

		glu.gluDisk(qobj, 0.0f, radius, nSlices, nStacks);
		gl.glTranslatef(0.0f, 0.0f, -length);
		gl.glRotatef(90.f, 1.0f, 0.0f, 0.0f);
		gl.glTranslatef(-rx, -ry, -rz);

		glu.gluDeleteQuadric(qobj);

	}

}
