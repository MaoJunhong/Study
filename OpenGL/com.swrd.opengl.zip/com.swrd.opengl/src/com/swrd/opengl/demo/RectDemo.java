/*
 * @(#)Simple.java
 * @author LiangZhang
 * Copyright 2013-3-29, LiangZhang all rights reserved
 */

package com.swrd.opengl.demo;

import javax.media.opengl.GL;
import javax.media.opengl.GLContext;
import javax.media.opengl.GLDrawableFactory;
import javax.media.opengl.glu.GLU;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.opengl.GLCanvas;
import org.eclipse.swt.opengl.GLData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

import com.swrd.opengl.utils.SWTUtils;

public class RectDemo {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setLayout(new FillLayout());
		shell.setSize(400, 300);
		SWTUtils.setCenter(shell);
		// ////////////////////////

		Composite comp = new Composite(shell, SWT.NONE);
		comp.setLayout(new FillLayout());

		GLData data = new GLData();
		data.doubleBuffer = true;
		final GLCanvas canvas = new GLCanvas(comp, SWT.NONE, data);
		canvas.setCurrent();

		final GLContext context = GLDrawableFactory.getFactory()
				.createExternalGLContext();

		canvas.addListener(SWT.Resize, new Listener() {

			@Override
			public void handleEvent(Event event) {
				Rectangle bounds = canvas.getBounds();
				canvas.setCurrent();
				context.makeCurrent();
				GL gl = context.getGL();
				gl.glViewport(0, 0, bounds.width, bounds.height);
				
				gl.glMatrixMode(GL.GL_PROJECTION);
				gl.glLoadIdentity();
				
				GLU glu = new GLU();
				glu.gluOrtho2D(-2, 2, -2, 2);
				context.release();
			}

		});

		// ////////////////////////

		shell.setText("SWT/LINE");
		shell.layout();
		shell.open();

		// ////////////////////////

		display.asyncExec(new Runnable() {
			public void run() {
				if (!canvas.isDisposed()) {
					canvas.setCurrent();
					context.makeCurrent();

					GL gl = context.getGL();
					gl.glClear(GL.GL_COLOR_BUFFER_BIT);
					gl.glClearColor(0.f, 1.f, 0.f, 0.5f);
					gl.glColor3f(1.0f, 0.0f, 0.0f);
					gl.glLineWidth(3);
					gl.glPointSize(0.50f);

					gl.glBegin(GL.GL_POLYGON);
					gl.glVertex2f(-0.5f, -0.5f);
					gl.glColor3f(1.0f,0.0f,0.0f);
					gl.glVertex2f(-0.5f, 0.5f);
					gl.glColor3f(1.0f,1.0f,1.0f);
					gl.glVertex2f(0.5f, 0.5f);
					gl.glColor3f(1.0f,1.0f,0.0f);
					gl.glVertex2f(0.5f, -0.5f);
					gl.glColor3f(1.0f,0.0f,1.0f);
					gl.glEnd();

					canvas.swapBuffers();
					context.release();
					display.asyncExec(this);
				}
			}
		});

		// ////////////////////////

		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		display.dispose();
	}

}
