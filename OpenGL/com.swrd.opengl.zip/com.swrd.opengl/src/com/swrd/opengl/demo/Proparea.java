/*
 * @(#)Proparea.java
 * @author LiangZhang
 * Copyright Apr 2, 2013, LiangZhang all rights reserved
 */
package com.swrd.opengl.demo;

import java.nio.FloatBuffer;

import javax.media.opengl.GL;
import javax.media.opengl.GLContext;
import javax.media.opengl.GLDrawableFactory;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.opengl.GLCanvas;
import org.eclipse.swt.opengl.GLData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

import com.swrd.opengl.utils.SWTUtils;

public class Proparea {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setLayout(new FillLayout());
		shell.setSize(400, 300);
		SWTUtils.setCenter(shell);

		Composite comp = new Composite(shell, SWT.NONE);
		comp.setLayout(new FillLayout());

		GLData data = new GLData();
		data.doubleBuffer = true;

		final GLCanvas canvas = new GLCanvas(comp, SWT.NONE, data);
		final GLContext context = GLDrawableFactory.getFactory()
				.createExternalGLContext();

		canvas.addListener(SWT.Resize, new Listener() {

			@Override
			public void handleEvent(Event event) {
				Rectangle bounds = event.getBounds();
				canvas.setCurrent();
				context.makeCurrent();

				GL gl = context.getGL();

				gl.glViewport(0, 0, bounds.width, bounds.height);
				gl.glMatrixMode(GL.GL_PROJECTION);
				gl.glLoadIdentity();

				gl.glOrtho(-5.0f, 5.0f, -5.0f, 5.0f, -5.0f, 5.0f);
				gl.glMatrixMode(GL.GL_MODELVIEW);
				
				context.release();
			}

		});

		shell.setText("Proparea");
		shell.layout();
		shell.open();

		display.asyncExec(new Runnable() {
			public void run() {
				if (!canvas.isDisposed()) {
					canvas.setCurrent();
					context.makeCurrent();

					GL gl = context.getGL();
					gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
					gl.glClearColor(0.f, 1.f, 0.f, 0.5f);
					gl.glColor3f(1.0f, 0.0f, 0.0f);
					gl.glLineWidth(3.0f);
					gl.glPointSize(5.0f);

					float cpts[][][] = new float[][][] {
							{ { -2, 0, 2 }, { -1, 2, 2 }, { 1, -2, 2 },
									{ 2, 0, 2 } },
							{ { -2, 0, 1 }, { -1, 2, 1 }, { 1, -2, 1 },
									{ 2, 0, 1 } },
							{ { -2, 0, 0 }, { -1, 2, 0 }, { 1, -2, 0 },
									{ 2, 0, 0 } },
							{ { -2, 0, -1 }, { -1, 2, -1 }, { 1, -2, -1 },
									{ 2, 0, -1 } } };

					FloatBuffer buffer = FloatBuffer.allocate(cpts.length
							* cpts[0].length * cpts[0][0].length);
					for (int i = 0; i < cpts.length; ++i) {
						for (int j = 0; j < cpts[i].length; ++j) {
							for (int k = 0; k < cpts[i][j].length; ++k) {
								buffer.put(cpts[i][j][k]);
							}
						}
					}
					buffer.rewind();

					gl.glEnable(GL.GL_MAP2_VERTEX_3);
					gl.glEnable(GL.GL_AUTO_NORMAL);
					gl.glEnable(GL.GL_NORMALIZE);
					gl.glMap2f(GL.GL_MAP2_VERTEX_3, 0.0f, 1.0f, 3, 4, 0.0f,
							1.0f, 12, 4, buffer);

					gl.glPushMatrix();
					gl.glRotatef(50.0f, 1.0f, 1.0f, 1.0f);
					gl.glMapGrid2f(20, 0.0f, 1.0f, 20, 0.0f, 1.0f);
					gl.glEvalMesh2(GL.GL_FILL, 0, 20, 0, 20);
					gl.glPopMatrix();
					gl.glFlush();

					canvas.swapBuffers();
					context.release();
					display.asyncExec(this);
				}
			}
		});

		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		display.dispose();
	}

}
