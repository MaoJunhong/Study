/*
 * @(#)Client.java
 * @author LiangZhang
 * Copyright Apr 7, 2013, LiangZhang all rights reserved
 */
package com.swrd.opengl.demo;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import com.swrd.opengl.Cylinder.Cylinder;
import com.swrd.opengl.Cylinder.CylinderCell;
import com.swrd.opengl.curve.Curve;
import com.swrd.opengl.curve.CurveCell;
import com.swrd.opengl.hist.Hist;
import com.swrd.opengl.hist.HistCell;
import com.swrd.opengl.sector.Sector;
import com.swrd.opengl.sector.SectorCell;
import com.swrd.opengl.utils.GLColor;
import com.swrd.opengl.utils.Paint;
import com.swrd.opengl.utils.Paint2D;
import com.swrd.opengl.utils.Paint3D;
import com.swrd.opengl.utils.SWTUtils;

public class Client {
	public static void main(String args[]) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setLayout(new FillLayout());
		shell.setSize(800, 800);
		SWTUtils.setCenter(shell);
		// ////////////////////////

		SashForm sashForm = new SashForm(shell, SWT.BORDER);
		SashForm leftSashForm = new SashForm(sashForm, SWT.VERTICAL);
		SashForm rightSashForm = new SashForm(sashForm, SWT.VERTICAL);

		final Paint leftUp = new Paint2D(leftSashForm, SWT.NONE);
		final Paint leftDown = new Paint3D(leftSashForm, SWT.NONE);
		final Paint rightUp = new Paint2D(rightSashForm, SWT.NONE);
		final Paint rightDown = new Paint2D(rightSashForm, SWT.NONE);

		Curve curive = new Curve();
		for (int i = 0; i <= 8; ++i) {
			curive.addElement(new CurveCell((float) (i + 1), (float) Math
					.random() * 8.0f));
		}
		leftUp.addDrawable(curive);

		Cylinder cylinder = new Cylinder();
		float size = 1.0f;
		for (int i = 1; i < 9; i += 2) {
			for (int j = 1; j < 9; j += 2) {
				CylinderCell ele = new CylinderCell(size / 1.8f,
						(float) (Math.random() * 8.0f), size * i, 0.0f, size
								* j, 30, 1, GLColor.getRandom());
				cylinder.addElement(ele);
			}
		}
		leftDown.addDrawable(cylinder);

		Hist hist = new Hist(0.6f);
		for (int i = 0; i < 8; ++i) {
			hist.addElement(new HistCell(i + 1, 0.6f, 0.0f, (float) Math
					.random() * 8, GLColor.getRandom()));
		}
		rightUp.addDrawable(hist);

		Sector sector = new Sector(3, 3, 3.0f, 30, 1);
		for (int i = 0; i <= 10; ++i) {
			sector.addElement(SectorCell.getRandom());

		}
		rightDown.addDrawable(sector);

		sashForm.setWeights(new int[] { 1, 1 });
		leftSashForm.setWeights(new int[] { 1, 1 });
		rightSashForm.setWeights(new int[] { 1, 1 });

		leftUp.setLayout(new FillLayout());
		leftDown.setLayout(new FillLayout());
		rightUp.setLayout(new FillLayout());
		rightDown.setLayout(new FillLayout());

		// shell.addListener(SWT.Resize, new Listener() {
		//
		// @Override
		// public void handleEvent(Event event) {
		// int min = (shell.getSize().x < shell.getSize().y ? shell
		// .getSize().x : shell.getSize().y) / 2 - 20;
		// leftUp.setBounds(5, 5, min, min);
		// leftDown.setBounds(5, min + 10, min, min);
		// rightUp.setBounds(0, 5, min, min);
		// rightDown.setBounds(0, min + 10, min, min);
		// }
		//
		// });

		shell.setText("SWT/Curive/Cylinder/Hist/Sector");
		shell.layout();
		shell.open();

		display.asyncExec(new Runnable() {
			@Override
			public void run() {
				leftUp.draw();
				leftDown.draw();
				rightUp.draw();
				rightDown.draw();
				display.asyncExec(this);
			}
		});

		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		display.dispose();
	}
}
