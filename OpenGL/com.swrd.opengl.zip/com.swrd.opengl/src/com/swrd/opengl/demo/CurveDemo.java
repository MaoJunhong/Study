/*
 * @(#)CuriveDemo.java
 * @author LiangZhang
 * Copyright 2013-4-2, LiangZhang all rights reserved
 */

package com.swrd.opengl.demo;

import java.nio.FloatBuffer;

import javax.media.opengl.GL;
import javax.media.opengl.GLContext;
import javax.media.opengl.GLDrawableFactory;
import javax.media.opengl.glu.GLU;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.opengl.GLCanvas;
import org.eclipse.swt.opengl.GLData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

import com.swrd.opengl.utils.SWTUtils;

public class CurveDemo {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setLayout(new FillLayout());
		shell.setSize(400, 300);
		SWTUtils.setCenter(shell);
		// ////////////////////////

		Composite comp = new Composite(shell, SWT.NONE);
		comp.setLayout(new FillLayout());

		GLData data = new GLData();
		data.doubleBuffer = true;

		final GLCanvas canvas = new GLCanvas(comp, SWT.NONE, data);

		final GLContext context = GLDrawableFactory.getFactory()
				.createExternalGLContext();

		canvas.addListener(SWT.Resize, new Listener() {
			@Override
			public void handleEvent(Event event) {
				Rectangle bounds = canvas.getBounds();
				canvas.setCurrent();
				context.makeCurrent();

				GL gl = context.getGL();
				gl.glViewport(0, 0, bounds.width, bounds.height);

				gl.glMatrixMode(GL.GL_PROJECTION);
				gl.glLoadIdentity();

				GLU glu = new GLU();
				glu.gluOrtho2D(-5, 5, -5, 5);
				context.release();
			}

		});

		// ////////////////////////

		shell.setText("SWT/LINE");
		shell.layout();
		shell.open();

		// ////////////////////////

		display.asyncExec(new Runnable() {
			public void run() {
				if (!canvas.isDisposed()) {
					canvas.setCurrent();
					context.makeCurrent();

					GL gl = context.getGL();
					gl.glClear(GL.GL_COLOR_BUFFER_BIT);
					gl.glClearColor(0.0f, 1.f, 0.f, 0.0f);
					gl.glColor4f(1.0f, 0.0f, 0.0f, 0.0f);
					gl.glLineWidth(3.0f);
					gl.glPointSize(5.0f);

					int ncpts = 4;
					float cpts[][] = new float[][] { { -4.0f, -0.0f, 0.0f },
							{ -2.0f, 1.0f, 0.0f }, { 0.0f, 4.0f, 0.0f },
							{ 3.0f, 4.0f, 0.0f } };

					FloatBuffer buffer = FloatBuffer.allocate(cpts.length
							* cpts[0].length);
					for (int i = 0; i < cpts.length; ++i) {
						for (int j = 0; j < cpts[i].length; ++j) {
							buffer.put(cpts[i][j]);
						}
					}
					buffer.rewind();

					// gl.glShadeModel(GL.GL_FLAT);
					gl.glMap1f(GL.GL_MAP1_VERTEX_3, 0.0f, 1.0f, 3, 3, buffer);
					// gl.glMapGrid1f(30, 0.0f, 1.0f);
					// gl.glEvalMesh1(GL.GL_LINE, 0, 30);

					gl.glEnable(GL.GL_MAP1_VERTEX_3);
					gl.glBegin(GL.GL_LINE_STRIP);
					for (int i = 0; i <= 100; ++i) {
						gl.glEvalCoord1f((float) i / (float) 100.0f);
					}
					gl.glEnd();

					// gl.glClear(GL.GL_COLOR_BUFFER_BIT);
					gl.glBegin(GL.GL_POINTS);
					for (int i = 0; i < ncpts; ++i) {
						gl.glVertex3fv(FloatBuffer.wrap(cpts[i]));
					}
					gl.glEnd();

					canvas.swapBuffers();
					context.release();
					display.asyncExec(this);
				}
			}
		});

		// ////////////////////////

		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		display.dispose();
	}

}
