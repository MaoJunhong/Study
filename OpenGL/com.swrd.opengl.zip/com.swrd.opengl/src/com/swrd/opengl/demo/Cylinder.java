/**
 * Class Cylinder
 * 
 * This class represents a cylinder.  The cylinder is drawn
 * using vertex arrays.  The data for the vertex array is stored
 * in a DoubleBuffer object.  Standard Java arrays can also be 
 * used.
 * 
 * @author David Wolff
 * 
 */

package com.swrd.opengl.demo;

import java.nio.DoubleBuffer;
import java.nio.IntBuffer;

import javax.media.opengl.GL;

import com.sun.opengl.util.BufferUtil;

public class Cylinder {

	// Number of slices and stacks
	private int nStacks, nSlices;
	// The length and radius of the cylinder
	private double length, radius;
	// Buffer for the vertex array
	private DoubleBuffer vertexBuffer;
	// Buffer for the normal arrray
	private DoubleBuffer normalBuffer;
	// Buffer for the index array
	private IntBuffer indexes;

	/**
	 * Initialize a new Cylinder, and build the vertex arrays.
	 * 
	 * @param slices
	 *            the number of slices around the z axis
	 * @param stacks
	 *            the number of stacks along the z axis
	 * @param length
	 *            the length of the cylinder
	 * @param radius
	 *            the radius of the cylinder
	 */
	public Cylinder(GL gl, int slices, int stacks, double length, double radius) {
		if (length <= 0) {
			throw new IllegalArgumentException(
					"Length must be greater than zero");
		}
		this.length = length;
		if (stacks < 1) {
			throw new IllegalArgumentException(
					"Number of stacks must be at least one.");
		}
		nStacks = stacks;
		if (slices < 3) {
			throw new IllegalArgumentException(
					"Number of slices must be at least three.");
		}
		nSlices = slices;
		if (radius <= 0) {
			throw new IllegalArgumentException(
					"Radius must be greater than zero.");
		}
		this.radius = radius;
		buildArrays(gl);
	}

	/*
	 * Draw the cylinder.
	 */
	public void draw(GL gl) {
		gl.glDrawElements(GL.GL_QUADS, nSlices * nStacks * 4,
				GL.GL_UNSIGNED_INT, indexes);
	}

	/*
	 * Builds the vertex arrays for this cylinder.
	 */
	private void buildArrays(GL gl) {
		int nVerts = (nStacks + 1) * nSlices;

		// Allocate space for the vertex and normal arrays. Note that
		// the BufferUtils class is used here for convenience. These
		// buffers can also be created using the java.nio methods.
		// For example:
		// vertexBuffer =
		// ByteBuffer.allocateDirect(sizeInBytes).asDoubleBuffer()
		vertexBuffer = BufferUtil.newDoubleBuffer(nVerts * 3);
		normalBuffer = BufferUtil.newDoubleBuffer(nVerts * 3);

		// Build the vertex and normal arrays
		double stackSize = length / nStacks;
		double angleInc = (2.0 * Math.PI) / nSlices;
		double angle;
		double[] vert = new double[3];
		double[] norm = new double[3];
		norm[2] = 0.0;
		for (int stack = 0; stack <= nStacks; stack++) {
			for (int slice = 0; slice < nSlices; slice++) {
				angle = angleInc * slice;
				vert[2] = stackSize * stack;

				norm[0] = Math.cos(angle);
				norm[1] = Math.sin(angle);
				vert[0] = radius * norm[0];
				vert[1] = radius * norm[1];

				vertexBuffer.put(vert);
				normalBuffer.put(norm);
			}
		}

		// Allocate space for the index array
		indexes = BufferUtil.newIntBuffer(nStacks * nSlices * 4);

		// Build the index array
		int[] quad = new int[4];
		for (int stack = 0; stack < nStacks; stack++) {
			for (int slice = 0; slice < nSlices; slice++) {
				quad[0] = (stack * nSlices) + slice;
				quad[1] = (stack * nSlices) + ((slice + 1) % nSlices);
				quad[2] = quad[1] + nSlices;
				quad[3] = quad[0] + nSlices;

				indexes.put(quad);
			}
		}

		vertexBuffer.rewind();
		normalBuffer.rewind();
		indexes.rewind();

		// Tell OpenGL where to find the arrays
		gl.glVertexPointer(3, GL.GL_DOUBLE, 0, vertexBuffer);
		gl.glNormalPointer(GL.GL_DOUBLE, 0, normalBuffer);
	}

}
