/*
 * @(#)CylinderDemo.java
 * @author LiangZhang
 * Copyright Apr 3, 2013, LiangZhang all rights reserved
 */
package com.swrd.opengl.demo;

import javax.media.opengl.GL;
import javax.media.opengl.GLContext;
import javax.media.opengl.GLDrawableFactory;
import javax.media.opengl.glu.GLU;
import javax.media.opengl.glu.GLUquadric;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.opengl.GLCanvas;
import org.eclipse.swt.opengl.GLData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

import com.swrd.opengl.utils.SWTUtils;

public class CylinderDemo {
	private static float angle = 0.0f;

	private static Cylinder cyl;

	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setLayout(new FillLayout());
		shell.setSize(400, 300);
		SWTUtils.setCenter(shell);
		// ////////////////////////

		Composite comp = new Composite(shell, SWT.NONE);
		comp.setLayout(new FillLayout());

		GLData data = new GLData();
		data.doubleBuffer = true;

		final GLCanvas canvas = new GLCanvas(comp, SWT.NONE, data);
		final GLContext context = GLDrawableFactory.getFactory()
				.createExternalGLContext();

		canvas.addListener(SWT.Resize, new Listener() {
			@Override
			public void handleEvent(Event event) {
				Rectangle bounds = canvas.getBounds();
				canvas.setCurrent();
				context.makeCurrent();

				GL gl = context.getGL();
				gl.glViewport(0, 0, bounds.width, bounds.height);

				gl.glMatrixMode(GL.GL_PROJECTION);
				gl.glLoadIdentity();

				GLU glu = new GLU();
				glu.gluPerspective(60.0f, (float) bounds.width / bounds.height,
						0.5f, 100.f);
				gl.glMatrixMode(GL.GL_MODELVIEW);
				gl.glLoadIdentity();

				// Enable the vertex array stuff
				gl.glEnableClientState(GL.GL_VERTEX_ARRAY);
				gl.glEnableClientState(GL.GL_NORMAL_ARRAY);

				cyl = new Cylinder(gl, 10, 10, 2.0, 0.3);
				context.release();
			}

		});

		// ////////////////////////

		shell.setText("SWT/LINE");
		shell.layout();
		shell.open();

		// ////////////////////////

		display.asyncExec(new Runnable() {
			public void run() {
				if (!canvas.isDisposed()) {
					canvas.setCurrent();
					context.makeCurrent();

					angle += 1.0f;
					if (angle > 180.f) {
						angle -= 360.f;
					}

					GL gl = context.getGL();
					gl.glClearColor(0.0f, 1.f, 0.f, 0.0f);
					gl.glColor4f(1.0f, 0.0f, 0.0f, 0.0f);

					GLU glu = new GLU();
					gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
					gl.glLoadIdentity();
					glu.gluLookAt(0, 2.0, 2.0, 0, 1, 0, 0, 1, 0);
					drawFloor(gl, true);

					gl.glRotated(angle, 0, 1, 0);
					//gl.glTranslated(0, 1, -1);
					cyl.draw(gl);

					GLUquadric qobj = glu.gluNewQuadric();

					gl.glRotatef(-90.f, 1.0f, 0.0f, 0.0f);
					glu.gluDisk(qobj, 0.0f, 0.5f, 5, 1);
					glu.gluCylinder(qobj, 0.5f, 0.5f, 0.5f, 32, 1);
					//gl.glTranslatef(0.0f, 0.0f, 2.0f);

					glu.gluDisk(qobj, 0.0f, 0.5f, 32, 1);
					//gl.glTranslatef(0.0f, 0.0f, -2.0f);
					//gl.glRotatef(90.f, 1.0f, 0.0f, 0.0f);

					glu.gluDeleteQuadric(qobj);

					canvas.swapBuffers();
					context.release();
					display.timerExec(50, this);
				}
			}
		});

		// ////////////////////////

		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		display.dispose();
	}

	private static void drawFloor(GL gl, boolean wireframe) {
		int xdivs = 50;
		int zdivs = 50;
		double xmin = -10.0, xmax = 10.0;
		double zmin = -10.0, zmax = 10.0;
		double x1, x2, y = 0.0, z;
		double xsize = (xmax - xmin) / xdivs;
		double zsize = (zmax - zmin) / zdivs;

		if (wireframe) {
			gl.glPushAttrib(GL.GL_LIGHTING_BIT | GL.GL_POLYGON_BIT
					| GL.GL_COLOR_BUFFER_BIT | GL.GL_TEXTURE_BIT);
			gl.glDisable(GL.GL_LIGHTING);
			gl.glDisable(GL.GL_TEXTURE_2D);
			gl.glPolygonMode(GL.GL_FRONT_AND_BACK, GL.GL_LINE);
			gl.glColor3f(1.0f, 0.2f, 0.2f);
		}

		for (int i = 0; i < xdivs; i++) {
			x1 = (i * xsize) + xmin;
			x2 = ((i + 1) * xsize) + xmin;

			gl.glBegin(GL.GL_QUAD_STRIP);
			for (int j = 0; j <= zdivs; j++) {
				z = (j * zsize) + zmin;
				gl.glVertex3d(x2, y, z);
				gl.glVertex3d(x1, y, z);
			}
			gl.glEnd();
		}

		if (wireframe) {
			gl.glPopAttrib();
		}
	}

}
