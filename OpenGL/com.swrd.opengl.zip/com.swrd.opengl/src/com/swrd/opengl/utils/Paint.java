/*
 * @(#)Paint.java
 * @author LiangZhang
 * Copyright Apr 7, 2013, LiangZhang all rights reserved
 */
package com.swrd.opengl.utils;

import java.util.ArrayList;
import java.util.List;

import javax.media.opengl.GL;
import javax.media.opengl.GLContext;
import javax.media.opengl.GLDrawableFactory;

import org.eclipse.swt.SWT;
import org.eclipse.swt.opengl.GLCanvas;
import org.eclipse.swt.opengl.GLData;
import org.eclipse.swt.widgets.Composite;

public class Paint extends Composite {

	protected List<Drawable> list;
	private float lineWidth = 1.0f, pointSize = 3.0f;
	private GLColor bgColor = new GLColor(0.5f, 0.5f, 0.5f, 1.0f);

	private final GLData data;
	protected final GLCanvas canvas;
	protected final GLContext context;

	public Paint(Composite parent, int style, float lineWidth, float pointSize,
			GLColor bgColor) {
		super(parent, style);

		this.lineWidth = lineWidth;
		this.pointSize = pointSize;
		this.bgColor = bgColor;

		this.list = new ArrayList<Drawable>();

		data = new GLData();
		data.doubleBuffer = true;

		canvas = new GLCanvas(this, SWT.NONE, data);
		context = GLDrawableFactory.getFactory().createExternalGLContext();
	}

	public Paint(Composite parent, int style) {
		super(parent, style);

		this.list = new ArrayList<Drawable>();

		data = new GLData();
		data.doubleBuffer = true;

		canvas = new GLCanvas(this, SWT.NONE, data);

		context = GLDrawableFactory.getFactory().createExternalGLContext();

	}

	public void draw() {
		GL gl = context.getGL();
		if (!canvas.isDisposed()) {
			canvas.setCurrent();
			context.makeCurrent();

			gl.glClear(GL.GL_COLOR_BUFFER_BIT);
			gl.glClearColor(bgColor.color_r, bgColor.color_g, bgColor.color_b,
					bgColor.color_c);

			gl.glLineWidth(lineWidth);
			gl.glPointSize(pointSize);

			gl.glPushMatrix();

			drawOthers(gl);
			// for (Drawable obj : list) {
			// obj.draw(gl);
			// }
			for (int i = list.size() - 1; i >= 0; --i) {
				list.get(i).draw(gl);
			}
			gl.glPopMatrix();

			canvas.swapBuffers();
			context.release();
		}
	}

	public void addDrawable(Drawable ele) {
		this.list.add(ele);
	}

	public void drawOthers(GL gl) {

	}

	public void setBgColor(GLColor bgColor) {
		this.bgColor = bgColor;
	}

	public void setLineWidth(float lineWidth) {
		this.lineWidth = lineWidth;
	}

	public void setPointSize(float pointSize) {
		this.pointSize = pointSize;
	}

}
