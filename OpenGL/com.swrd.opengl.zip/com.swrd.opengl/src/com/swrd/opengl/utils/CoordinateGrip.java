/*
 * @(#)CoordinateListener.java
 * @author LiangZhang
 * Copyright Apr 7, 2013, LiangZhang all rights reserved
 */
package com.swrd.opengl.utils;

import javax.media.opengl.GL;

import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseMoveListener;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.opengl.GLCanvas;

import com.sun.opengl.util.GLUT;

public class CoordinateGrip implements MouseMoveListener, Drawable {
	private GLCanvas canvas;
	private float xLow, xHigh, yLow, yHigh;
	private float xRatio, yRatio;
	private float x, y, offset = 0.5f;
	private GLColor color = new GLColor(1.0f, 1.0f, 1.0f, 1.0f);

	public CoordinateGrip(GLCanvas canvas, float xLow, float xRatio,
			float yLow, float yRatio) {
		this.canvas = canvas;
		this.xLow = xLow;
		this.xRatio = xRatio;
		this.yLow = yLow;
		this.yRatio = yRatio;
	}

	@Override
	public void mouseMove(MouseEvent e) {
		Rectangle rect = canvas.getBounds();
		xHigh = (float) rect.width / xRatio + xLow;
		yHigh = (float) rect.height / yRatio + yLow;

		x = (float) e.x / rect.width * (xHigh - xLow);
		y = (float) e.y / rect.height * (yHigh - yLow);

		x += xLow;
		y = yHigh - y;
	}

	@Override
	public void draw(GL gl) {
		GLUT glut = new GLUT();

		String s = "( ";
		s += String.format("%.2f", x);
		s += " , ";
		s += String.format("%.2f", y);
		s += " )";

		gl.glColor4f(color.color_r, color.color_g, color.color_b, color.color_c);
		gl.glBegin(GL.GL_POINTS);
		gl.glVertex2f(x, y);
		gl.glEnd();

		glut.glutBitmapString(GLUT.BITMAP_TIMES_ROMAN_24, s);
		gl.glRasterPos2d(x + offset, y - offset);
	}

	public void setOffset(float offset) {
		this.offset = offset;
	}

	public void setColor(GLColor color) {
		this.color = color;
	}

}
