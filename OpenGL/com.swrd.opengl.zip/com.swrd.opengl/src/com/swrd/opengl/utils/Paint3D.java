/*
 * @(#)Paint3D.java
 * @author LiangZhang
 * Copyright Apr 7, 2013, LiangZhang all rights reserved
 */
package com.swrd.opengl.utils;

import javax.media.opengl.GL;
import javax.media.opengl.glu.GLU;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;

public class Paint3D extends Paint {
	private float xLow = 0.0f, xHigh = 8.0f, yLow = 0.0f, yHigh = 8.0f,
			zLow = 0.0f, zHigh = 8.0f;
	private GLColor gridxColor = new GLColor(1.0f, 0.0f, 0.0f, 0.0f);
	private GLColor gridyColor = new GLColor(0.0f, 1.0f, 0.0f, 0.0f);
	private GLColor gridzColor = new GLColor(0.0f, 0.0f, 1.0f, 0.0f);

	private SceneGrip kls;

	public Paint3D(Composite parent, int style, float xLow, float xHigh,
			float yLow, float yHigh, float zLow, float zHigh, float lineWidth,
			float pointSize, GLColor bgColor, GLColor gridxColor,
			GLColor gridyColor, GLColor gridzColor) {
		super(parent, style, lineWidth, pointSize, bgColor);

		this.xLow = xLow;
		this.xHigh = xHigh;
		this.yLow = yLow;
		this.yHigh = yHigh;
		this.zLow = zLow;
		this.zHigh = zHigh;
		this.gridxColor = gridxColor;
		this.gridyColor = gridyColor;
		this.gridzColor = gridzColor;

		kls = new SceneGrip();

		init();
	}

	public Paint3D(Composite parent, int style) {
		super(parent, style);

		kls = new SceneGrip();

		init();
	}

	private void init() {
		canvas.addListener(SWT.Resize, new Listener() {

			@Override
			public void handleEvent(Event event) {
				Rectangle bounds = canvas.getBounds();
				canvas.setCurrent();
				context.makeCurrent();

				GL gl = context.getGL();
				gl.glViewport(0, 0, bounds.width, bounds.height);

				gl.glMatrixMode(GL.GL_PROJECTION);
				gl.glLoadIdentity();
				// gl.glOrtho(xLow, xHigh, yLow, yHigh, zLow, zHigh);
				GLU glu = new GLU();
				glu.gluPerspective(
						80.0f,
						(float) bounds.width / bounds.height,
						0.0f,
						Math.sqrt((xHigh - xLow) * (xHigh - xLow)
								+ (yHigh - yLow) * (yHigh - yLow)
								+ (zHigh - zLow) * (zHigh - zLow)));

				gl.glMatrixMode(GL.GL_MODELVIEW);
				gl.glLoadIdentity();
				glu.gluLookAt(xHigh, yHigh, zHigh, xLow, yLow, zLow, 0.0f,
						1.0f, 0.0f);

				context.release();
			}

		});

		canvas.addKeyListener(kls);
	}

	@Override
	public void drawOthers(GL gl) {
		kls.adjust(gl);

		DrawFlat.drawFlatXZ(gl, true, gridyColor, xLow, xHigh, zLow, zHigh);
		DrawFlat.drawFlatXY(gl, true, gridzColor, xLow, xHigh, yLow, yHigh);
		DrawFlat.drawFlatYZ(gl, true, gridxColor, yLow, yHigh, zLow, zHigh);
	}

	public void setxLow(float xLow) {
		this.xLow = xLow;
	}

	public void setyLow(float yLow) {
		this.yLow = yLow;
	}

	public void setyHigh(float yHigh) {
		this.yHigh = yHigh;
	}

	public void setzLow(float zLow) {
		this.zLow = zLow;
	}

	public void setzHigh(float zHigh) {
		this.zHigh = zHigh;
	}

	public void setGridxColor(GLColor gridxColor) {
		this.gridxColor = gridxColor;
	}

	public void setGridyColor(GLColor gridyColor) {
		this.gridyColor = gridyColor;
	}

	public void setGridzColor(GLColor gridzColor) {
		this.gridzColor = gridzColor;
	}
}
