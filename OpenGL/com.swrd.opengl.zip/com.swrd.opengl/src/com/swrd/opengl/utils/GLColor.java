/*
 * @(#)GLColor.java
 * @author LiangZhang
 * Copyright 2013-3-31, LiangZhang all rights reserved
 */

package com.swrd.opengl.utils;

public class GLColor {
	public float color_r, color_g, color_b, color_c;

	public GLColor(float colorR, float colorG, float colorB, float colorC) {
		color_r = colorR;
		color_g = colorG;
		color_b = colorB;
		color_c = colorC;
	}

	public static GLColor getRandom() {
		return new GLColor((float) Math.random(), (float) Math.random(),
				(float) Math.random(), (float) Math.random());
	}
}
