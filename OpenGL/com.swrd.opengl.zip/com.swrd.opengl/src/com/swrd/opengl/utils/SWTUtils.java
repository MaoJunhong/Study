package com.swrd.opengl.utils;

import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Shell;

public class SWTUtils {

	public static void setCenter(Shell shell) {
		Rectangle rtg = shell.getMonitor().getClientArea();
		shell.setLocation((rtg.width - shell.getSize().x) / 2,
				(rtg.height - shell.getSize().y) / 2);
	}

}
