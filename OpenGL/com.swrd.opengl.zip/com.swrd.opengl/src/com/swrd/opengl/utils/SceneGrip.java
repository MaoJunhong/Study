/*
 * @(#)MyKeyListener.java
 * @author LiangZhang
 * Copyright Apr 3, 2013, LiangZhang all rights reserved
 */
package com.swrd.opengl.utils;

import javax.media.opengl.GL;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;

public class SceneGrip implements KeyListener {

	private float xrot;
	private float yrot;
	private float zoff;
	private float xoff;
	private float yoff;

	public SceneGrip() {
		this.init();
	}

	private void init() {
		this.xrot = this.yrot = 0.0f;
		this.xoff = this.yoff = 0.0f;
	}

	@Override
	public void keyPressed(KeyEvent e) {
		switch (e.keyCode) {
		case SWT.ARROW_UP:
			if ((e.stateMask & SWT.ALT) != 0) {
				this.xrot -= 0.5f;
			} else {
				this.yoff += 0.05f;
			}
			break;
		case SWT.ARROW_DOWN:
			if ((e.stateMask & SWT.ALT) != 0) {
				this.xrot += 0.5f;
			} else {
				this.yoff -= 0.05f;
			}
			break;
		case SWT.ARROW_LEFT:
			if ((e.stateMask & SWT.ALT) != 0) {
				this.yrot -= 0.5f;
			} else {
				this.xoff -= 0.05f;
			}
			break;
		case SWT.ARROW_RIGHT:
			if ((e.stateMask & SWT.ALT) != 0) {
				this.yrot += 0.5f;
			} else {
				this.xoff += 0.05f;
			}
			break;
		case SWT.PAGE_UP:
			this.zoff += 0.05f;
			break;
		case SWT.PAGE_DOWN:
			this.zoff -= 0.05f;
			break;
		case SWT.HOME:
			this.init();
			break;
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {

	}

	public void adjust(GL gl) {
		gl.glTranslated(xoff, yoff, zoff);
		gl.glRotatef(this.xrot, 1.0f, 0.0f, 0.0f);
		gl.glRotatef(this.yrot, 0.0f, 1.0f, 0.0f);		
	}
}
