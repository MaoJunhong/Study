/*
 * @(#)Drawable.java
 * @author LiangZhang
 * Copyright 2013-3-31, LiangZhang all rights reserved
 */

package com.swrd.opengl.utils;

import javax.media.opengl.GL;

public interface Drawable {
	void draw(GL gl);
}
