/*
 * @(#)PaintComposite.java
 * @author LiangZhang
 * Copyright 2013-3-31, LiangZhang all rights reserved
 */

package com.swrd.opengl.utils;

import javax.media.opengl.GL;
import javax.media.opengl.glu.GLU;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;

public class Paint2D extends Paint {
	private float xLow = -1.0f, xHigh = 9.0f;
	private float yLow = -1.0f, yHigh = 9.f;
	private float xRatio = 40.0f, yRatio = 40.f;
	private GLColor axColor = new GLColor(1.0f, 0.0f, 0.0f, 1.0f);
	private GLColor gridColor = new GLColor(1.0f, 1.0f, 1.0f, 0.0f);

	private CoordinateGrip cl;

	public Paint2D(Composite parent, int style, float xLow, float xRatio,
			float yLow, float yRatio, float lineWidth, float pointSize,
			GLColor bgColor, GLColor axColor, GLColor gridColor) {
		super(parent, style, lineWidth, pointSize, bgColor);

		this.xLow = xLow;
		this.yLow = yLow;

		this.xRatio = xRatio;
		this.yRatio = yRatio;

		this.axColor = axColor;
		this.gridColor = gridColor;

		init();
	}

	public Paint2D(Composite parent, int style) {
		super(parent, style);

		init();
	}

	private void init() {

		canvas.addListener(SWT.Resize, new Listener() {

			@Override
			public void handleEvent(Event event) {
				Rectangle bounds = canvas.getBounds();
				canvas.setCurrent();
				context.makeCurrent();

				GL gl = context.getGL();
				gl.glViewport(0, 0, bounds.width, bounds.height);

				xHigh = (float) bounds.width / xRatio + xLow;
				yHigh = (float) bounds.height / yRatio + yLow;

				gl.glMatrixMode(GL.GL_PROJECTION);
				gl.glLoadIdentity();
				GLU glu = new GLU();
				glu.gluOrtho2D(xLow, xHigh, yLow, yHigh);

				context.release();
			}

		});

		cl = new CoordinateGrip(canvas, xLow, xRatio, yLow, yRatio);
		canvas.addMouseMoveListener(cl);
		list.add(cl);
	}

	@Override
	public void drawOthers(GL gl) {
		DrawFlat.drawFlatXY(gl, true, gridColor, xLow, xHigh, yLow, yHigh);
		drawAxis(gl);
		// cl.draw(gl);
	}

	public void drawAxis(GL gl) {
		gl.glColor4f(axColor.color_r, axColor.color_g, axColor.color_b,
				axColor.color_c);

		gl.glBegin(GL.GL_LINES);
		gl.glVertex3f(0, yLow, 0);
		gl.glVertex3f(0, yHigh, 0);
		gl.glEnd();

		gl.glBegin(GL.GL_LINES);
		gl.glVertex3f(xLow, 0, 0);
		gl.glVertex3f(xHigh, 0, 0);
		gl.glEnd();
	}

	public void setxLow(float xLow) {
		this.xLow = xLow;
	}

	public void setxHigh(float xHigh) {
		this.xHigh = xHigh;
	}

	public void setxRatio(float xRatio) {
		this.xRatio = xRatio;
	}

	public void setyRatio(float yRatio) {
		this.yRatio = yRatio;
	}

	public void setAxColor(GLColor axColor) {
		this.axColor = axColor;
	}

	public void setGridColor(GLColor gridColor) {
		this.gridColor = gridColor;
	}

}
