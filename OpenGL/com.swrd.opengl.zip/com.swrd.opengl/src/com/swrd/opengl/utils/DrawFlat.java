/*
 * @(#)DrawFlat.java
 * @author LiangZhang
 * Copyright Apr 7, 2013, LiangZhang all rights reserved
 */
package com.swrd.opengl.utils;

import javax.media.opengl.GL;

public class DrawFlat {

	public static void drawFlatXZ(GL gl, boolean wireframe, GLColor color,
			float xmin, float xmax, float zmin, float zmax) {
		float y = 0;
		xmin = (float) Math.ceil(xmin);
		xmax = (float) Math.floor(xmax);
		zmin = (float) Math.ceil(zmin);
		zmax = (float) Math.floor(zmax);

		if (wireframe) {
			gl.glPushAttrib(GL.GL_LIGHTING_BIT | GL.GL_POLYGON_BIT
					| GL.GL_COLOR_BUFFER_BIT | GL.GL_TEXTURE_BIT);
			gl.glDisable(GL.GL_LIGHTING);
			gl.glDisable(GL.GL_TEXTURE_2D);
			gl.glPolygonMode(GL.GL_FRONT_AND_BACK, GL.GL_LINE);
			gl.glColor4f(color.color_r, color.color_g, color.color_b,
					color.color_c);
		}

		for (float xi = xmin; xi <= xmax; ++xi) {
			gl.glBegin(GL.GL_LINES);
			gl.glVertex3f(xi, y, zmin);
			gl.glVertex3f(xi, y, zmax);
			gl.glEnd();
		}
		for (float zi = zmin; zi <= zmax; ++zi) {
			gl.glBegin(GL.GL_LINES);
			gl.glVertex3f(xmin, y, zi);
			gl.glVertex3f(xmax, y, zi);
			gl.glEnd();
		}

		if (wireframe) {
			gl.glPopAttrib();
		}
	}

	public static void drawFlatXY(GL gl, boolean wireframe, GLColor color,
			float xmin, float xmax, float ymin, float ymax) {
		float z = 0;
		xmin = (float) Math.ceil(xmin);
		xmax = (float) Math.floor(xmax);
		ymin = (float) Math.ceil(ymin);
		ymax = (float) Math.floor(ymax);

		if (wireframe) {
			gl.glPushAttrib(GL.GL_LIGHTING_BIT | GL.GL_POLYGON_BIT
					| GL.GL_COLOR_BUFFER_BIT | GL.GL_TEXTURE_BIT);
			gl.glDisable(GL.GL_LIGHTING);
			gl.glDisable(GL.GL_TEXTURE_2D);
			gl.glPolygonMode(GL.GL_FRONT_AND_BACK, GL.GL_LINE);
			gl.glColor4f(color.color_r, color.color_g, color.color_b,
					color.color_c);
		}

		for (float xi = xmin; xi <= xmax; ++xi) {
			gl.glBegin(GL.GL_LINES);
			gl.glVertex3f(xi, ymin, z);
			gl.glVertex3f(xi, ymax, z);
			gl.glEnd();
		}
		for (float yi = ymin; yi <= ymax; ++yi) {
			gl.glBegin(GL.GL_LINES);
			gl.glVertex3f(xmin, yi, z);
			gl.glVertex3f(xmax, yi, z);
			gl.glEnd();
		}

		if (wireframe) {
			gl.glPopAttrib();
		}
	}

	public static void drawFlatYZ(GL gl, boolean wireframe, GLColor color,
			float ymin, float ymax, float zmin, float zmax) {
		float x = 0;

		ymin = (float) Math.ceil(ymin);
		ymax = (float) Math.floor(ymax);
		zmin = (float) Math.ceil(zmin);
		zmax = (float) Math.floor(zmax);

		if (wireframe) {
			gl.glPushAttrib(GL.GL_LIGHTING_BIT | GL.GL_POLYGON_BIT
					| GL.GL_COLOR_BUFFER_BIT | GL.GL_TEXTURE_BIT);
			gl.glDisable(GL.GL_LIGHTING);
			gl.glDisable(GL.GL_TEXTURE_2D);
			gl.glPolygonMode(GL.GL_FRONT_AND_BACK, GL.GL_LINE);
			gl.glColor4f(color.color_r, color.color_g, color.color_b,
					color.color_c);
		}

		for (float yi = ymin; yi <= ymax; ++yi) {
			gl.glBegin(GL.GL_LINES);
			gl.glVertex3f(x, yi, zmin);
			gl.glVertex3f(x, yi, zmax);
			gl.glEnd();
		}
		for (float zi = zmin; zi <= zmax; ++zi) {
			gl.glBegin(GL.GL_LINES);
			gl.glVertex3f(x, ymin, zi);
			gl.glVertex3f(x, ymax, zi);
			gl.glEnd();
		}

		if (wireframe) {
			gl.glPopAttrib();
		}
	}

}
