/*
 * @(#)RotatePoint.java
 * @author LiangZhang
 * Copyright 2013-3-31, LiangZhang all rights reserved
 */

package com.swrd.opengl.utils;

public class RotatePoint {
	public static float getX(float x, float y, float ratio) {
		return (float) (x * Math.cos(ratio) + y * Math.sin(ratio));
	}

	public static float getY(float x, float y, float ratio) {
		return (float) (-x * Math.sin(ratio) + y * Math.cos(ratio));
	}
}
