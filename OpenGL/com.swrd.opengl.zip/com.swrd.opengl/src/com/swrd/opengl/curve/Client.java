/*
 * @(#)Client.java
 * @author LiangZhang
 * Copyright 2013-4-2, LiangZhang all rights reserved
 */

package com.swrd.opengl.curve;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import com.swrd.opengl.utils.Paint2D;
import com.swrd.opengl.utils.SWTUtils;

public class Client {
	
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setLayout(new FillLayout());
		shell.setSize(800, 600);
		SWTUtils.setCenter(shell);
		// ////////////////////////

		Curve curive = new Curve();
		for (int i = 8; i >= 0; --i) {
			curive.addElement(new CurveCell((float) (i + 1), (float) Math
					.random() * 9.0f));
		}

		final Paint2D paint = new Paint2D(shell, SWT.NONE);
		paint.addDrawable(curive);
		paint.setLayout(new FillLayout());

		// ////////////////////////

		shell.setText("SWT/Curive");
		shell.layout();
		shell.open();

		display.asyncExec(new Runnable() {
			@Override
			public void run() {
				paint.draw();
				display.asyncExec(this);
			}
		});

		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		display.dispose();
	}
}
