/*
* @(#)CuriveCell.java
* @author LiangZhang
* Copyright Apr 7, 2013, LiangZhang all rights reserved
*/
package com.swrd.opengl.curve;

public class CurveCell {
	
	private float x;
	private float y;

	public CurveCell(float x, float y) {
		this.x = x;
		this.y = y;
	}

	public float getX() {
		return x;
	}

	public float getY() {
		return y;
	}

}
