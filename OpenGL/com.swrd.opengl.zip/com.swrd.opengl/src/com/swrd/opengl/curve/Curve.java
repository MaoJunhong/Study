/*
 * @(#)Curive.java
 * @author LiangZhang
 * Copyright 2013-4-2, LiangZhang all rights reserved
 */

package com.swrd.opengl.curve;

import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.List;

import javax.media.opengl.GL;

import com.swrd.opengl.utils.Drawable;
import com.swrd.opengl.utils.GLColor;

public class Curve implements Drawable {

	private List<CurveCell> list;
	private float offX, offY;
	private float curvature = 2.1f;
	private GLColor color;

	public Curve() {
		this.color = new GLColor(1.0f, 1.0f, 0.0f, 0.7f);
		this.list = new ArrayList<CurveCell>();
	}

	public void addElement(CurveCell ele) {
		list.add(ele);
	}

	@Override
	public void draw(GL gl) {
		gl.glColor4f(color.color_r, color.color_g, color.color_b, color.color_c);

		if (list.size() < 2) {
			return;
		}
		offX = list.get(0).getX() - 1.0f;
		offY = list.get(0).getY() - 1.0f;

		for (int i = 1; i < list.size(); ++i) {
			drawSeg2(list.get(i - 1), list.get(i), gl);
		}
	}

	public void drawSeg1(CurveCell start, CurveCell end, GL gl) {

		float startX = start.getX(), startY = start.getY();
		float endX = end.getX(), endY = end.getY();

		if (startX > endX) {
			float tmp = startX;
			startX = endX;
			endX = tmp;

			tmp = startY;
			startY = endY;
			endY = tmp;
		}

		offX = start.getX() * 2 - offX;
		offY = start.getY() * 2 - offY;

		float cpts[][] = new float[][] { { startX, startY, 0.0f },
				{ offX, offY, 0.0f }, { endX, endY, 0.0f } };

		FloatBuffer buffer = FloatBuffer.allocate(cpts.length * cpts[0].length);
		for (int i = 0; i < cpts.length; ++i) {
			for (int j = 0; j < cpts[i].length; ++j) {
				buffer.put(cpts[i][j]);
			}
		}
		buffer.rewind();

		gl.glMap1f(GL.GL_MAP1_VERTEX_3, 0.0f, 1.0f, 3, 3, buffer);
		gl.glEnable(GL.GL_MAP1_VERTEX_3);

		gl.glMapGrid1f(300, 0.0f, 1.0f);
		gl.glEvalMesh1(GL.GL_LINE, 0, 300);

		// gl.glBegin(GL.GL_LINE_STRIP);
		// for (int i = 0; i <= 100; ++i) {
		// gl.glEvalCoord1f((float) i / (float) 100.0f);
		// } gl.glEnd();

		// gl.glBegin(GL.GL_POINTS);
		// for (int i = 0; i < cpts.length; ++i) {
		// gl.glVertex3fv(FloatBuffer.wrap(cpts[i]));
		// }
		// gl.glEnd();
	}

	public void drawSeg2(CurveCell start, CurveCell end, GL gl) {

		float startX = start.getX(), startY = start.getY();
		float endX = end.getX(), endY = end.getY();

		if (startX > endX) {
			float tmp = startX;
			startX = endX;
			endX = tmp;

			tmp = startY;
			startY = endY;
			endY = tmp;
		}

		float midx = (startX + endX) / 2;
		float midy = (startY + endY) / 2;
		float offsetx = Math.abs(startX - endX) / curvature;
		float offsety = Math.abs(startY - endY) / curvature;
		float flap = startY > endY ? 1.0f : -1.0f;

		float cpts[][] = new float[][] { { startX, startY, 0.0f },
				{ midx + offsetx, midy + flap * offsety, 0.0f },
				{ midx - offsetx, midy - flap * offsety, 0.0f },
				{ endX, endY, 0.0f } };

		FloatBuffer buffer = FloatBuffer.allocate(cpts.length * cpts[0].length);
		for (int i = 0; i < cpts.length; ++i) {
			for (int j = 0; j < cpts[i].length; ++j) {
				buffer.put(cpts[i][j]);
			}
		}
		buffer.rewind();

		gl.glMap1f(GL.GL_MAP1_VERTEX_3, 0.0f, 1.0f, 3, 4, buffer);
		gl.glEnable(GL.GL_MAP1_VERTEX_3);

		gl.glMapGrid1f(100, 0.0f, 1.0f);
		gl.glEvalMesh1(GL.GL_LINE, 0, 100);

		// gl.glBegin(GL.GL_LINE_STRIP);
		// for (int i = 0; i <= 100; ++i) {
		// gl.glEvalCoord1f((float) i / (float) 100.0f);
		// } gl.glEnd();

		// gl.glBegin(GL.GL_POINTS);
		// for (int i = 0; i < cpts.length; ++i) {
		// gl.glVertex3fv(FloatBuffer.wrap(cpts[i]));
		// }
		// gl.glEnd();
	}

	public void setCurvature(float curvature) {
		this.curvature = curvature;
	}

	public void setColor(GLColor color) {
		this.color = color;
	}

}
