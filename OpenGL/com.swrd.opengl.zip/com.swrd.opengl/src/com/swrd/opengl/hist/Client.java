/*
 * @(#)Client.java
 * @author LiangZhang
 * Copyright 2013-3-31, LiangZhang all rights reserved
 */

package com.swrd.opengl.hist;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import com.swrd.opengl.utils.GLColor;
import com.swrd.opengl.utils.Paint2D;
import com.swrd.opengl.utils.SWTUtils;

public class Client {

	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setLayout(new FillLayout());
		shell.setSize(400, 300);
		SWTUtils.setCenter(shell);

		// ////////////////////////

		Hist hist = new Hist(0.6f);
		for (int i = 0; i < 9; ++i) {
			hist.addElement(new HistCell(i + 1, 0.6f, 0.0f, (float) Math
					.random() * 9, GLColor.getRandom()));
		}

		final Paint2D paint = new Paint2D(shell, SWT.NONE);
		paint.addDrawable(hist);
		paint.setLayout(new FillLayout());

		// ////////////////////////

		shell.setText("SWT/Hist");
		shell.layout();
		shell.open();

		display.asyncExec(new Runnable() {
			@Override
			public void run() {
				paint.draw();
				display.asyncExec(this);
			}
		});

		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		display.dispose();
	}
}
