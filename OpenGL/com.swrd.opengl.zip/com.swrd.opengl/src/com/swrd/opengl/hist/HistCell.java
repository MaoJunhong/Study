/*
 * @(#)HistCell.java
 * @author LiangZhang
 * Copyright 2013-3-31, LiangZhang all rights reserved
 */

package com.swrd.opengl.hist;

import javax.media.opengl.GL;

import com.swrd.opengl.utils.Drawable;
import com.swrd.opengl.utils.GLColor;

public class HistCell implements Drawable {
	private float pos;
	private float width;
	private float heightLow;
	private float heightHigh;

	private GLColor color;

	public HistCell(float pos, float width, float heightLow, float heightHigh,
			GLColor color) {
		this.pos = pos;
		this.width = width;
		this.heightLow = heightLow;
		this.heightHigh = heightHigh;
		this.color = color;
	}

	@Override
	public void draw(GL gl) {
		gl.glColor4f(color.color_r, color.color_g, color.color_b, color.color_c);

		gl.glBegin(GL.GL_POLYGON);
		gl.glVertex2f(pos - width / 2, heightLow);
		gl.glVertex2f(pos + width / 2, heightLow);
		gl.glVertex2f(pos + width / 2, heightHigh);
		gl.glVertex2f(pos - width / 2, heightHigh);
		gl.glEnd();
	}

}
