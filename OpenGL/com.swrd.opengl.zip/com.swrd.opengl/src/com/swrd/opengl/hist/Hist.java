/*
 * @(#)Hist.java
 * @author LiangZhang
 * Copyright 2013-3-31, LiangZhang all rights reserved
 */

package com.swrd.opengl.hist;

import java.util.ArrayList;
import java.util.List;

import javax.media.opengl.GL;

import com.swrd.opengl.utils.Drawable;

public class Hist implements Drawable {

	private List<HistCell> list;

	public Hist(float width) {
		this.list = new ArrayList<HistCell>();
	}

	@Override
	public void draw(GL gl) {

		for (int i = 0; i < list.size(); ++i) {
			list.get(i).draw(gl);
		}

	}

	public void addElement(HistCell cell) {
		list.add(cell);
	}

}
