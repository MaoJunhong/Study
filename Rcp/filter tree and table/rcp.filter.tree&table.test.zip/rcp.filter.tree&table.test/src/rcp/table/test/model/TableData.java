package rcp.table.test.model;

public class TableData {

	public String ta;
	public String tb;
	public String tc;
}
