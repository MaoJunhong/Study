package rcp.table.test;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.StructuredViewer;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.dialogs.FilteredTree;
import org.eclipse.ui.dialogs.PatternFilter;
import org.eclipse.ui.internal.misc.StringMatcher;
import org.eclipse.ui.part.ViewPart;

import rcp.table.test.model.TableData;

public class View extends ViewPart {
	public static final String ID = "rcp.table.test.view";

	private TreeViewer dirV;

	private TreeViewer treV;
	private Text treST;
	private TreePatternFilter trePF;

	private TableViewer tabV;
	private Text tabST;
	private TablePatternFilter tabPF;

	/**
	 * This is a callback that will allow us to create the viewer and initialize
	 * it.
	 */
	public void createPartControl(Composite parent) {
		parent.setLayout(new FillLayout());
		SashForm sashForm = new SashForm(parent, SWT.NONE);
		Composite dirComp = new Composite(sashForm, SWT.NONE);
		Composite treeComp = new Composite(sashForm, SWT.NONE);
		Composite tabComp = new Composite(sashForm, SWT.NONE);
		sashForm.setWeights(new int[] { 1, 1, 1 });

		createDir(dirComp);
		createTree(treeComp);
		createTable(tabComp);

	}

	/**
	 * Passing the focus request to the viewer's control.
	 */
	public void setFocus() {
	}

	private String getRandomString() {
		String s = "";
		int l = 1 + (int) (Math.random() * 10);
		for (int j = 0; j < l; ++j) {
			s += (char) ('a' + (int) (Math.random() * 26));
		}
		return s;
	}

	// /////////////////////////
	private void createDir(Composite parent) {
		parent.setLayout(new GridLayout());

		FilteredTree ft = new FilteredTree(parent, SWT.NONE,
				new DirPatternFilter(), true);
		ft.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

		dirV = ft.getViewer();
		dirV.setContentProvider(new DirContentProvider());
		dirV.setLabelProvider(new DirLabelProvider());
		dirV.setInput(new File(System.getProperty("user.home")).listFiles());
	}

	public class DirPatternFilter extends PatternFilter {

		@Override
		public boolean isElementVisible(Viewer viewer, Object element) {
			// TODO Auto-generated method stub
			return super.isElementVisible(viewer, element);
		}

		public boolean isMatch(Viewer viewer, Object element) {
			DirContentProvider dcp = (DirContentProvider) ((TreeViewer) viewer)
					.getLabelProvider();

			while (true) {
				Object parent = dcp.getParent(element);
				if (parent == null) {
					break;
				}
				if (isLeafMatch(viewer, parent)) {
					return true;
				}
				element = parent;
			}
			return false;
		}

	}

	public class DirContentProvider implements ITreeContentProvider {

		@Override
		public void dispose() {
			// TODO Auto-generated method stub

		}

		@Override
		public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
			// TODO Auto-generated method stub

		}

		@Override
		public Object[] getElements(Object inputElement) {
			return (File[]) inputElement;
		}

		@Override
		public Object[] getChildren(Object parentElement) {
			return ((File) parentElement).listFiles();
		}

		@Override
		public Object getParent(Object element) {
			return new File(((File) element).getParent());
		}

		@Override
		public boolean hasChildren(Object element) {
			return ((File) element).isDirectory();
		}

	}

	public class DirLabelProvider extends LabelProvider {
		@Override
		public String getText(Object element) {
			return ((File) element).getName();
		}
	}

	// /////////////////////////

	private void createTree(Composite parent) {
		parent.setLayout(new GridLayout());
		trePF = new TreePatternFilter();

		treST = new Text(parent, SWT.SINGLE | SWT.BORDER | SWT.SEARCH
				| SWT.ICON_CANCEL | SWT.ICON_SEARCH);
		treST.setMessage("type filter text");
		treST.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
		treST.addModifyListener(new ModifyListener() {
			@Override
			public void modifyText(ModifyEvent e) {
				treTextChanged();
			}
		});

		treV = new TreeViewer(parent, SWT.V_SCROLL | SWT.H_SCROLL | SWT.MULTI);
		treV.setContentProvider(new TreeContentProvider());
		treV.setLabelProvider(new TreeLabelProvider());
		treV.addFilter(trePF);

		treV.getTree().setLayoutData(
				new GridData(SWT.FILL, SWT.FILL, true, true));
		List<String> treeLists = new ArrayList<String>();
		for (int i = 0; i < 1000; ++i) {
			treeLists.add(getRandomString());
		}
		treV.setInput(treeLists);
	}

	protected void treTextChanged() {
		String text = treST.getText();
		trePF.setPattern(text);

		treV.getControl().setRedraw(false);
		treV.refresh(true);
		treV.getControl().setRedraw(true);
	}

	public class TreePatternFilter extends ViewerFilter {
		private StringMatcher matcher;

		@Override
		public boolean select(Viewer viewer, Object parentElement,
				Object element) {
			TreeLabelProvider itcp = (TreeLabelProvider) ((TreeViewer) viewer)
					.getLabelProvider();

			if (matcher != null) {
				return matcher.match(itcp.getText(element));
			}
			return true;
		}

		public void setPattern(String patternString) {
			if (patternString == null || patternString.equals("")) { //$NON-NLS-1$
				matcher = null;
			} else {
				String pattern = patternString + "*"; //$NON-NLS-1$
				// if (includeLeadingWildcard) {
				//					pattern = "*" + pattern; //$NON-NLS-1$
				// }
				matcher = new StringMatcher(pattern, true, false);
			}
		}

	}

	public class TreeContentProvider implements ITreeContentProvider {

		@Override
		public void dispose() {
			// TODO Auto-generated method stub

		}

		@Override
		public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
			// TODO Auto-generated method stub

		}

		@Override
		public Object[] getElements(Object inputElement) {
			List<String> list = (List<String>) inputElement;
			return list.toArray();
		}

		@Override
		public Object[] getChildren(Object parentElement) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Object getParent(Object element) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public boolean hasChildren(Object element) {
			// TODO Auto-generated method stub
			return false;
		}

	}

	public class TreeLabelProvider extends LabelProvider {

		@Override
		public String getText(Object element) {
			return (String) element;
		}

	}

	// /////////////////////////

	private void createTable(Composite parent) {
		parent.setLayout(new GridLayout());
		tabPF = new TablePatternFilter();

		tabST = new Text(parent, SWT.SINGLE | SWT.BORDER | SWT.SEARCH
				| SWT.ICON_CANCEL | SWT.ICON_SEARCH);
		tabST.setMessage("type filter text");
		tabST.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
		tabST.addModifyListener(new ModifyListener() {
			@Override
			public void modifyText(ModifyEvent e) {
				tabTextChanged();
			}
		});

		tabV = new TableViewer(parent, SWT.MULTI | SWT.H_SCROLL | SWT.V_SCROLL);
		tabV.setContentProvider(new ViewContentProvider());
		tabV.setLabelProvider(new ViewLabelProvider());
		tabV.addFilter(tabPF);

		Table table = tabV.getTable();
		table.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		table.setLinesVisible(true);
		table.setHeaderVisible(true);
		{
			TableColumn tc = new TableColumn(table, SWT.NONE);
			tc.setText("ta");
			tc.setWidth(100);
		}
		{
			TableColumn tc = new TableColumn(table, SWT.NONE);
			tc.setText("tb");
			tc.setWidth(100);
		}
		{
			TableColumn tc = new TableColumn(table, SWT.NONE);
			tc.setText("tc");
			tc.setWidth(100);
		}

		// Provide the input to the ContentProvider
		List<TableData> tableLists = new ArrayList<TableData>();
		for (int i = 0; i < 1000; i++) {
			{
				TableData data = new TableData();
				data.ta = getRandomString();
				data.tb = getRandomString();
				data.tc = getRandomString();
				tableLists.add(data);
			}
			{
				TableData data = new TableData();
				data.ta = getRandomString();
				data.tb = getRandomString();
				data.tc = getRandomString();
				tableLists.add(data);
			}
			{
				TableData data = new TableData();
				data.ta = getRandomString();
				data.tb = getRandomString();
				data.tc = getRandomString();
				tableLists.add(data);
			}
		}
		tabV.setInput(tableLists);
	}

	protected void tabTextChanged() {
		String text = tabST.getText();
		tabPF.setPattern(text);

		tabV.getControl().setRedraw(false);
		tabV.refresh(true);
		tabV.getControl().setRedraw(true);
	}

	public class TablePatternFilter extends ViewerFilter {
		/**
		 * The string pattern matcher used for this pattern filter.
		 */
		private StringMatcher matcher;

		@Override
		public boolean select(Viewer viewer, Object parentElement,
				Object element) {

			return isAnyColumnVisible(viewer, element, ((TableViewer) viewer)
					.getTable().getColumnCount());
		}

		private boolean isAnyColumnVisible(Viewer viewer, Object rowElement,
				int columnCount) {
			ITableLabelProvider tableLabelProvider = ((ITableLabelProvider) ((StructuredViewer) viewer)
					.getLabelProvider());
			if (tableLabelProvider == null) {
				return false;
			}

			for (int i = 0; i < columnCount; i++) {
				String lableStringText = tableLabelProvider.getColumnText(
						rowElement, i);
				if (lableStringText != null && match(lableStringText))
					return true;
			}

			return false;
		}

		/**
		 * The pattern string for which this filter should select elements in
		 * the viewer.
		 * 
		 * @param patternString
		 */
		public void setPattern(String patternString) {
			if (patternString == null || patternString.equals("")) { //$NON-NLS-1$
				matcher = null;
			} else {
				String pattern = patternString + "*"; //$NON-NLS-1$
				// if (includeLeadingWildcard) {
				//					pattern = "*" + pattern; //$NON-NLS-1$
				// }
				matcher = new StringMatcher(pattern, true, false);
			}
		}

		/**
		 * Answers whether the given String matches the pattern.
		 * 
		 * @param string
		 *            the String to test
		 * 
		 * @return whether the string matches the pattern
		 */
		private boolean match(String string) {
			if (matcher == null) {
				return true;
			}
			return matcher.match(string);
		}
	}

	/**
	 * The content provider class is responsible for providing objects to the
	 * view. It can wrap existing objects in adapters or simply return objects
	 * as-is. These objects may be sensitive to the current input of the view,
	 * or ignore it and always show the same content (like Task List, for
	 * example).
	 */
	class ViewContentProvider implements IStructuredContentProvider {
		public void inputChanged(Viewer v, Object oldInput, Object newInput) {
		}

		public void dispose() {
		}

		public Object[] getElements(Object parent) {
			if (parent instanceof Object[]) {
				return (Object[]) parent;
			}
			if (parent instanceof List) {
				return ((List) parent).toArray();
			}
			return new Object[0];
		}
	}

	class ViewLabelProvider extends LabelProvider implements
			ITableLabelProvider {
		public String getColumnText(Object obj, int index) {
			if (obj instanceof TableData) {
				TableData data = (TableData) obj;
				if (index == 0)
					return data.ta;
				if (index == 1)
					return data.tb;
				if (index == 2)
					return data.tc;
			}
			return getText(obj);
		}

		public Image getColumnImage(Object obj, int index) {
			return getImage();
		}

		public Image getImage() {
			return PlatformUI.getWorkbench().getSharedImages()
					.getImage(ISharedImages.IMG_OBJ_ELEMENT);
		}
	}
}
