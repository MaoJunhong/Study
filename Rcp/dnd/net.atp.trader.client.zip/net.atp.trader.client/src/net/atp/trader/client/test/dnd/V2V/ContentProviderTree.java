package net.atp.trader.client.test.dnd.V2V;

import java.util.ArrayList;
import java.util.List;

public enum ContentProviderTree {
	INSTANCE;
	List<String> list = new ArrayList<String>();

	private ContentProviderTree() {
		list.add("Branch1");
		list.add("Branch1");
	}

	public List<String> getModel() {
		return list;
	}
}
