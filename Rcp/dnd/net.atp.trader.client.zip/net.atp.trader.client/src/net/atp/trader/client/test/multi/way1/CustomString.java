package net.atp.trader.client.test.multi.way1;

import java.util.Locale;
import java.util.ResourceBundle;

public class CustomString {
	private static final String BUNDLE_NAME = "net.atp.trader.client.test.multi.way1.custom";
	private static ResourceBundle rb = null;

	public static void main(String args[]) {
		// CustomString.setLocale(Locale.getDefault());
		CustomString.setLocale(Locale.CHINA);
		// CustomString.setLocale(Locale.FRENCH);
		System.out.println(CustomString.getString(Constants.MAIN_WINDOW_TITLE));
	}

	/*
	 * @param locale: 通过locale来设置初始化的资源文件
	 */
	public static void setLocale(Locale locale) {
		try {
			rb = ResourceBundle.getBundle(BUNDLE_NAME, locale);
		} catch (Exception e) {
			rb = ResourceBundle.getBundle(BUNDLE_NAME, Locale.ENGLISH);
		}
	}

	/*
	 * @param key: 获得key相对应的value值
	 */
	public static String getString(String key) {
		try {
			String keyValue = new String(rb.getString(key).getBytes(
					"ISO-8859-1"), "UTF-8");
			// return keyValue;
			return rb.getString(key);
		} catch (Exception e) {
			return key;
		}
	}

}
