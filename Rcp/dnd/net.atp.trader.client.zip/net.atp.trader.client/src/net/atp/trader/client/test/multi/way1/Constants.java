package net.atp.trader.client.test.multi.way1;

public class Constants {
	public static String MAIN_WINDOW_TITLE = "MAIN_WINDOW_TITLE";
	public static String MENU_FILE = "MENU_FILE";
	public static String MENU_FILE_SAY_HELLO = "MENU_FILE_SAY_HELLO";
	public static String MENU_HELP = "MENU_HELP";
	public static String DIALOG_TITLE = "DIALOG_TITLE";
	public static String DIALOG_MESSAGE = "DIALOG_MESSAGE";
}
