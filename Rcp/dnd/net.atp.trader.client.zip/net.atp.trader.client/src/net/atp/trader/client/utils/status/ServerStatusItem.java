package net.atp.trader.client.utils.status;

import net.atp.trader.client.Application;

import org.eclipse.jface.action.StatusLineContributionItem;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.ui.plugin.AbstractUIPlugin;

public class ServerStatusItem extends StatusLineContributionItem {
	private Label priceServer;
	private Label businessServer;

	public ServerStatusItem(String id) {
		super(id);
	}

	@Override
	public void fill(Composite parent) {
		priceServer = new Label(parent, SWT.NONE);
		businessServer = new Label(parent, SWT.NONE);

		setStatus(priceServer, "24-em-check", "price server is connect!");
		setStatus(businessServer, "24-em-cross",
				"business server is not connect!");

		priceServer.addListener(SWT.MouseDown, new Listener() {

			@Override
			public void handleEvent(Event event) {
				MessageDialog.openConfirm(null, "Price", "abc");
			}
		});

		super.fill(parent);
	}

	public void setStatus(Label label, String color, String toolTip) {
		label.setToolTipText(toolTip);
		label.setImage(AbstractUIPlugin.imageDescriptorFromPlugin(
				Application.PLUGIN_ID, "icons/" + color + ".png").createImage());

	}

}
