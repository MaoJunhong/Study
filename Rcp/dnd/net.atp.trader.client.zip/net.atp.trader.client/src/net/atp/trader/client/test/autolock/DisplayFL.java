package net.atp.trader.client.test.autolock;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

public class DisplayFL {
	public static void main(String[] args) {
		Display display = Display.getDefault();
		Shell shell = new Shell(display);
		shell.setLayout(new RowLayout());

		// Button button = new Button(shell, SWT.NONE);
		// button.setText("You can touch me now!");
		// button.setFocus();

		// display.addFilter(SWT.KeyDown, new Listener() {
		//
		// @Override
		// public void handleEvent(Event event) {
		// System.out.println("display filter!");
		// }
		// });

		display.addListener(SWT.KeyDown, new Listener() {

			@Override
			public void handleEvent(Event event) {
				System.out.println("display listener!");
			}
		});

		// button.addListener(SWT.MouseDown, new Listener() {
		//
		// @Override
		// public void handleEvent(Event event) {
		// System.out.println("button listener!");
		// }
		// });

		shell.setSize(300, 150);
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

}
