package net.atp.trader.client;

import net.atp.trader.client.utils.status.ServerStatusItem;

import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IStatusLineManager;
import org.eclipse.jface.action.StatusLineContributionItem;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.application.ActionBarAdvisor;
import org.eclipse.ui.application.IActionBarConfigurer;

public class ApplicationActionBarAdvisor extends ActionBarAdvisor {
	private ServerStatusItem serverStatus;
	private StatusLineContributionItem ATP_Status;

	public ApplicationActionBarAdvisor(IActionBarConfigurer configurer) {
		super(configurer);
	}

	protected void makeActions(IWorkbenchWindow window) {
		serverStatus = new ServerStatusItem("server status");
		serverStatus.setVisible(true);

		ATP_Status = new StatusLineContributionItem("ATP status");
		ATP_Status.setText("ATP");
	}

	protected void fillMenuBar(IMenuManager menuBar) {
	}

	@Override
	protected void fillStatusLine(IStatusLineManager statusLine) {
		super.fillStatusLine(statusLine);
		statusLine.add(serverStatus);
		// statusLine.add(ATP_Status);

	}
}
