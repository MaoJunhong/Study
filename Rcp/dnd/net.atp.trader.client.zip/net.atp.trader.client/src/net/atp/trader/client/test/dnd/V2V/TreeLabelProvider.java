package net.atp.trader.client.test.dnd.V2V;

import org.eclipse.jface.viewers.LabelProvider;

public class TreeLabelProvider extends LabelProvider {

	@Override
	public String getText(Object element) {
		return (String) (element);
	}

}
