package net.atp.trader.client.utils;

import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Shell;

public class SWTUtils {

	/*
	 * Set the shell on the center of the screen
	 * 
	 * @param shell the shell which needs setCentered
	 */
	public static void setCenter(Shell shell) {
		Rectangle rtg = shell.getMonitor().getClientArea();
		shell.setLocation((rtg.width - shell.getSize().x) / 2,
				(rtg.height - shell.getSize().y) / 2);
	}

}
