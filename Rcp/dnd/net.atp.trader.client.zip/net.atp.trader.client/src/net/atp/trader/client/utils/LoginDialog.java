package net.atp.trader.client.utils;

import net.atp.trader.client.Application;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.IMessageProvider;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.plugin.AbstractUIPlugin;

public class LoginDialog extends TitleAreaDialog {

	private Text userNameText;
	private Text passwordText;
	private Button enter;

	public LoginDialog(Shell parentShell) {
		super(parentShell);
	}

	@Override
	protected void configureShell(Shell newShell) {
		super.configureShell(newShell);

		newShell.setSize(1020, 640);
		SWTUtils.setCenter(newShell);
	}

	@Override
	protected Control createContents(Composite parent) {
		Control contents = super.createContents(parent);

		setMessage(
				"welcome to advance transform platform, please log in to continue...",
				IMessageProvider.INFORMATION);

		return contents;
	}

	@Override
	protected Control createDialogArea(Composite parent) {

		Composite composite = new Composite(parent, SWT.BORDER);
		composite.setSize(364, 225);
		composite.setLayoutData(new GridData(GridData.FILL_BOTH));
		composite.setBackgroundImage(AbstractUIPlugin
				.imageDescriptorFromPlugin(Application.PLUGIN_ID,
						"/icons/login_bg.png").createImage());

		composite.setLayout(new FormLayout());

		{
			userNameText = new Text(composite, SWT.BORDER | SWT.SINGLE);
			FontData fontData = userNameText.getFont().getFontData()[0];
			fontData.setHeight(25);
			Font font = new Font(Display.getDefault(), fontData);
			userNameText.setFont(font);

			FormData fd = new FormData(200, 40);
			fd.left = new FormAttachment(0, 250);
			fd.top = new FormAttachment(0, 200);
			userNameText.setLayoutData(fd);
			userNameText.setMessage("user name...");
		}

		{
			passwordText = new Text(composite, SWT.BORDER | SWT.SINGLE);
			FontData fontData = passwordText.getFont().getFontData()[0];
			fontData.setHeight(25);
			Font font = new Font(Display.getDefault(), fontData);
			passwordText.setFont(font);

			FormData fd = new FormData(200, 40);
			fd.left = new FormAttachment(0, 470);
			fd.top = new FormAttachment(0, 200);
			passwordText.setLayoutData(fd);
			passwordText.setMessage("password...");
			passwordText.setEchoChar('*');
		}

		{
			enter = new Button(composite, SWT.PUSH);
			FormData fd = new FormData(55, 60);
			fd.left = new FormAttachment(0, 690);
			fd.top = new FormAttachment(0, 193);
			enter.setLayoutData(fd);
			enter.setImage(AbstractUIPlugin.imageDescriptorFromPlugin(
					Application.PLUGIN_ID, "/icons/enter.png").createImage());

			enter.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					buttonPressed(IDialogConstants.OK_ID);
				}
			});
			parent.getShell().setDefaultButton(enter);
		}

		return composite;
	}

	@Override
	protected Control createButtonBar(Composite parent) {
		return null;
		// return super.createButtonBar(parent);
	}

	@Override
	protected void buttonPressed(int buttonId) {
		String userName = userNameText.getText();
		String password = passwordText.getText();

		if (userName == null || userName.equals("") || password == null
				|| password.equals("")) {
			setErrorMessage("username or password can not be null");
		}
		okPressed();
	}

	public String getPasswordTxt() {
		return passwordText.getText();
	}

	public String getUserNameTxt() {
		return userNameText.getText();
	}

}
