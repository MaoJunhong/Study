package net.atp.trader.client.test.autolock;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
public class AutoLockTest {
	private static long idleThresholdSecs = 10;
	private static long lastActivityAt = System.currentTimeMillis();
	private static Display display = Display.getDefault();
	private static Shell shell = new Shell(display);
	private static Button bt = new Button(shell, SWT.NONE);
	public static void main(String[] args) {
		shell.setLayout(new FillLayout());
		bt.setText("You can touch me now!");
		lock();
		shell.setSize(300, 150);
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
	private static void lock() {
		lockAL();
		display.asyncExec(new Runnable() {
			@Override
			public void run() {
				while (!shell.isDisposed()) {
					lockRAD();
					System.out.println(lastActivityAt);
					// 如果时间间隔超过阈值，锁起来
					if (System.currentTimeMillis() - lastActivityAt > idleThresholdSecs * 1000) {
						bt.setText("You cannot touch me now!"); // 改变文本
						bt.setEnabled(false); // 设置按钮不可点击
					}
					display.sleep(); // display没有系统事件了，睡觉
				}
			}
		});
	}
	private static void lockRAD() {
		while (display.readAndDispatch()) { // 能读取系统事件
			lastActivityAt = System.currentTimeMillis(); // 更新最后的操作时间
			System.out.println("lastActivityAt changed by RAD!");
		}
	}
	private static void lockAL() {
		final Runnable handler = new Runnable() {
			@Override
			public void run() {
				lastActivityAt = System.currentTimeMillis(); // 更新最后的操作时间
				System.out.println("lastActivityAt changed by AL!");
			}
		};
		Listener listener = new Listener() {
			@Override
			public void handleEvent(Event event) {
				display.syncExec(handler);
			}
		};
		display.addFilter(SWT.MouseMove, listener); // 给Display添加监听器
		display.addFilter(SWT.KeyUp, listener);
		// more events...
	}
}
