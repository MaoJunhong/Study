package net.atp.trader.client.bills.query;

import org.eclipse.jface.action.IStatusLineManager;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IPartListener;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;

public class CurrentBillView extends ViewPart {
	public static final String ID = "net.atp.trader.client.bills.query.current.view";

	public CurrentBillView() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void createPartControl(Composite parent) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setFocus() {
		PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
				.addPartListener(new IPartListener() {

					@Override
					public void partOpened(IWorkbenchPart part) {
						// TODO Auto-generated method stub

					}

					@Override
					public void partDeactivated(IWorkbenchPart part) {
						// TODO Auto-generated method stub

					}

					@Override
					public void partClosed(IWorkbenchPart part) {
						// TODO Auto-generated method stub

					}

					@Override
					public void partBroughtToTop(IWorkbenchPart part) {
						// TODO Auto-generated method stub

					}

					@Override
					public void partActivated(IWorkbenchPart part) {
						IStatusLineManager statusLine = getViewSite()
								.getActionBars().getStatusLineManager();
						statusLine.setMessage(null, ID);
					}
				});
	}

}
