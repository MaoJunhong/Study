package net.atp.trader.client.test.dnd.V2V;

import java.util.ArrayList;
import java.util.List;

public class ContentProviderTable {

	public enum ContentProvider {
		  INSTANCE;
		  
		  public List<Todo> getModel(){
		    List<Todo> list = new ArrayList<Todo>();
		    Todo todo = new Todo("Java", "Learn the Closure proposal");
		    list.add(todo);
		    todo = new Todo("Eclipse", "Learn more about the RCP platform");
		    list.add(todo);
		    return list;
		  }
	}
}
