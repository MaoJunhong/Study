package net.atp.trader.client.test.widgets;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.ToolTip;

public class SpinnerSnippet {

	public static void main(String[] args) {
		final Display display = new Display();
		final Shell shell = new Shell(display);
		shell.setText("Spinner with float values");
		shell.setLayout(new GridLayout());
		{
			final Spinner spinner = new Spinner(shell, SWT.NONE);
			// allow 3 decimal places
			spinner.setDigits(3);
			// set the minimum value to 0.001
			spinner.setMinimum(1);
			// set the maximum value to 20
			spinner.setMaximum(200000000);
			// set the increment value to 0.010
			spinner.setIncrement(10);
			// set the seletion to 3.456
			spinner.setSelection(13456);

			spinner.addSelectionListener(new SelectionAdapter() {
				public void widgetSelected(SelectionEvent e) {
					int selection = spinner.getSelection();
					int digits = spinner.getDigits();
					System.out.println("Selection is "
							+ (selection / Math.pow(10, digits)));
				}
			});
		}
		{
			final Spinner spinner = new Spinner(shell, SWT.BORDER);
			spinner.setValues(0, -100, 100, 0, 1, 10);
			spinner.setLayoutData(new GridData(200, SWT.DEFAULT));
			spinner.addModifyListener(new ModifyListener() {
				ToolTip toolTip = new ToolTip(shell, SWT.BALLOON
						| SWT.ICON_WARNING);

				public void modifyText(ModifyEvent e) {
					String string = spinner.getText();
					String message = null;
					try {
						int value = Integer.parseInt(string);
						int maximum = spinner.getMaximum();
						int minimum = spinner.getMinimum();
						if (value > maximum) {
							message = "Current input is greater than the maximum limit ("
									+ maximum + ")";
						} else if (value < minimum) {
							message = "Current input is less than the minimum limit ("
									+ minimum + ")";
						}
					} catch (Exception ex) {
						message = "Current input is not numeric";
					}
					if (message != null) {
						spinner.setForeground(display
								.getSystemColor(SWT.COLOR_RED));
						Rectangle rect = spinner.getBounds();
						GC gc = new GC(spinner);
						Point pt = gc.textExtent(string);
						gc.dispose();
						toolTip.setLocation(display.map(shell, null, rect.x
								+ pt.x, rect.y + rect.height));
						toolTip.setMessage(message);
						toolTip.setVisible(true);
					} else {
						toolTip.setVisible(false);
						spinner.setForeground(null);
					}
				}
			});
		}
		shell.setSize(200, 200);
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}