package net.atp.trader.client;

import net.atp.trader.client.account.bank.CashStatusView;
import net.atp.trader.client.bills.create.CreateBillView;
import net.atp.trader.client.bills.query.CurrentBillView;
import net.atp.trader.client.bills.query.HistoryBillView;
import net.atp.trader.client.bills.query.PositionView;
import net.atp.trader.client.log.CurrentLogView;
import net.atp.trader.client.market.price.MarketPriceView;

import org.eclipse.ui.IFolderLayout;
import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;

public class Perspective implements IPerspectiveFactory {

	public void createInitialLayout(IPageLayout layout) {
		layout.setEditorAreaVisible(false);

		// layout.addView(DragAndDropView.ID, IPageLayout.TOP, 0.01f,
		// layout.getEditorArea());
		// layout.addView(TableView.ID, IPageLayout.BOTTOM, 0.3f,
		// DragAndDropView.ID);
		// layout.addView(TreeView.ID, IPageLayout.RIGHT, 0.4f, TableView.ID);
		layout.addView(CashStatusView.ID, IPageLayout.TOP, 0.01f,
				layout.getEditorArea());
		layout.addView(MarketPriceView.ID, IPageLayout.BOTTOM, 0.15f,
				CashStatusView.ID);
		layout.addView(CreateBillView.ID, IPageLayout.RIGHT, 0.7f,
				MarketPriceView.ID);

		IFolderLayout downLeft = layout.createFolder("downLeft",
				IPageLayout.BOTTOM, 0.6f, MarketPriceView.ID);
		downLeft.addView(CurrentBillView.ID);
		downLeft.addView(PositionView.ID);
		layout.addView(HistoryBillView.ID, IPageLayout.BOTTOM, 0.4f,
				CreateBillView.ID);
		layout.addView(CurrentLogView.ID, IPageLayout.BOTTOM, 0.7f,
				CurrentBillView.ID);
	}
}
