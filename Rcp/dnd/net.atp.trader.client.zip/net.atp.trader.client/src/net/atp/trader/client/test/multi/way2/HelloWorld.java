package net.atp.trader.client.test.multi.way2;

public class HelloWorld {

	public static void main(String[] args) {
		System.out.println(Messages.HelloWorld_key);

	}

}
